/* Ilagay dito ang Supabase project URL at anon/public key mula sa Supabase dashboard.
   HUWAG ilagay ang service_role key o anumang secret key sa browser code. */
window.SIKAIN_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY_HERE"
};
